

/* =========================================================
   Spotify Explorer — Frontend App
   ========================================================= */

// ─── State ────────────────────────────────────────────────
const state = {
  currentView: 'home',
  searchQuery: '',
  searchType: 'track',
  searchOffset: 0,
  searchTotal: 0,
  audio: null,
  playingTrackId: null,
  genreSeeds: [],
  activeGenre: null,
};

// ─── DOM Refs ──────────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ─── Greeting ─────────────────────────────────────────────
function setGreeting() {
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  $('#greeting').textContent = `${greet} 👋`;
}

// ─── View Navigation ──────────────────────────────────────
function showView(name) {
  $$('.view').forEach((v) => v.classList.remove('active'));
  $$('.nav-btn').forEach((b) => b.classList.remove('active'));
  $(`#view-${name}`).classList.add('active');
  $(`[data-view="${name}"]`).classList.add('active');
  state.currentView = name;

  // Close sidebar on mobile
  if (window.innerWidth <= 768) {
    $('#sidebar').classList.remove('open');
  }
}

// ─── Toast ────────────────────────────────────────────────
function showToast(msg, duration = 2500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ─── API Helpers ──────────────────────────────────────────
async function apiFetch(url) {
  const res = await fetch(url);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ─── Image Helper ─────────────────────────────────────────
function imgOrPlaceholder(images, cls = '', emoji = '🎵') {
  const src = images && images.length ? images[0].url : null;
  if (src) return `<img src="${src}" alt="" class="${cls}" loading="lazy" />`;
  return `<div class="${cls.replace('card-img', 'card-img-placeholder')}">${emoji}</div>`;
}

// ─── Duration Format ──────────────────────────────────────
function fmtMs(ms) {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

// ─── Card Builders ────────────────────────────────────────
function buildTrackCard(track) {
  const artists = track.artists.map((a) => a.name).join(', ');
  const img = track.album?.images;
  return `
    <div class="card" data-type="track" data-id="${track.id}" data-preview="${track.preview_url || ''}">
      <div class="card-img-wrap">
        ${imgOrPlaceholder(img, 'card-img', '🎵')}
        <button class="card-play-btn" aria-label="Preview">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
      <span class="card-badge badge-track">Track</span>
      <div class="card-title">${escHtml(track.name)}</div>
      <div class="card-sub">${escHtml(artists)}</div>
    </div>`;
}

function buildArtistCard(artist) {
  return `
    <div class="card" data-type="artist" data-id="${artist.id}">
      <div class="card-img-wrap">
        ${imgOrPlaceholder(artist.images, 'card-img circle', '🎤')}
        <button class="card-play-btn" aria-label="View">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
      <span class="card-badge badge-artist">Artist</span>
      <div class="card-title">${escHtml(artist.name)}</div>
      <div class="card-sub">${artist.genres?.slice(0, 2).join(', ') || 'Artist'}</div>
    </div>`;
}

function buildAlbumCard(album) {
  const artists = album.artists?.map((a) => a.name).join(', ') || '';
  return `
    <div class="card" data-type="album" data-id="${album.id}">
      <div class="card-img-wrap">
        ${imgOrPlaceholder(album.images, 'card-img', '💿')}
        <button class="card-play-btn" aria-label="View">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
      <span class="card-badge badge-album">Album</span>
      <div class="card-title">${escHtml(album.name)}</div>
      <div class="card-sub">${escHtml(artists)}</div>
    </div>`;
}

function buildPlaylistCard(pl) {
  if (!pl || !pl.id) return '';
  return `
    <div class="card" data-type="playlist" data-id="${pl.id}">
      <div class="card-img-wrap">
        ${imgOrPlaceholder(pl.images, 'card-img', '🎧')}
        <button class="card-play-btn" aria-label="View">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
      <div class="card-title">${escHtml(pl.name)}</div>
      <div class="card-sub">${escHtml(pl.description || pl.owner?.display_name || '')}</div>
    </div>`;
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── Modal ────────────────────────────────────────────────
function openModal(html) {
  $('#modalContent').innerHTML = html;
  $('#modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  $('#modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

// ─── Artist Modal ─────────────────────────────────────────
async function showArtistModal(artistId) {
  openModal('<div class="empty-state"><div class="empty-icon">⏳</div><p>Loading…</p></div>');
  try {
    const data = await apiFetch(`/api/artist/${artistId}`);
    const { artist, albums } = data;
    const artistImg = artist.images?.length
      ? `<img src="${artist.images[0].url}" alt="${escHtml(artist.name)}" class="modal-artist-img" />`
      : `<div class="modal-artist-img-placeholder">🎤</div>`;

    const albumCards = albums.items?.length
      ? albums.items.map((a) => `
          <div class="card" data-type="album" data-id="${a.id}" style="cursor:pointer">
            <div class="card-img-wrap">
              ${imgOrPlaceholder(a.images, 'card-img', '💿')}
            </div>
            <div class="card-title">${escHtml(a.name)}</div>
            <div class="card-sub">${a.release_date?.slice(0, 4) || ''} · ${escHtml(a.album_type || '')}</div>
          </div>`).join('')
      : '<p style="color:var(--text-muted)">No albums found.</p>';

    const spotifyUrl = artist.external_urls?.spotify || '#';

    openModal(`
      <div class="modal-artist-header">
        ${artistImg}
        <div class="modal-artist-info">
          <h2>${escHtml(artist.name)}</h2>
          <p>${artist.genres?.slice(0, 3).join(' · ') || 'Artist'}</p>
          <a href="${spotifyUrl}" target="_blank" rel="noopener" class="spotify-link">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>
            Open in Spotify
          </a>
        </div>
      </div>
      <p class="modal-section-title">Albums & Singles</p>
      <div class="cards-grid" style="grid-template-columns: repeat(auto-fill, minmax(140px,1fr))">
        ${albumCards}
      </div>
    `);

    // Bind album clicks inside modal
    $('#modalContent').querySelectorAll('[data-type="album"]').forEach((el) => {
      el.addEventListener('click', () => showAlbumModal(el.dataset.id));
    });
  } catch (e) {
    openModal(`<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`);
  }
}

// ─── Album Modal ──────────────────────────────────────────
async function showAlbumModal(albumId) {
  openModal('<div class="empty-state"><div class="empty-icon">⏳</div><p>Loading…</p></div>');
  try {
    const album = await apiFetch(`/api/album/${albumId}`);
    const albumImg = album.images?.length
      ? `<img src="${album.images[0].url}" alt="${escHtml(album.name)}" class="modal-album-img" />`
      : `<div class="modal-album-img-placeholder">💿</div>`;

    const artists = album.artists?.map((a) => a.name).join(', ') || '';
    const spotifyUrl = album.external_urls?.spotify || '#';

    const tracks = album.tracks?.items || [];
    const trackRows = tracks.map((t, i) => {
      const previewBtn = t.preview_url
        ? `<button class="track-preview-btn" data-preview="${t.preview_url}" data-id="${t.id}" aria-label="Preview">
             <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
           </button>`
        : '';
      return `
        <li class="track-item">
          <span class="track-num">${i + 1}</span>
          <div class="track-info">
            <div class="track-name">${escHtml(t.name)}</div>
            <div class="track-artist">${escHtml(t.artists?.map((a) => a.name).join(', ') || '')}</div>
          </div>
          <span class="track-duration">${fmtMs(t.duration_ms)}</span>
          ${previewBtn}
        </li>`;
    }).join('');

    openModal(`
      <div class="modal-album-header">
        ${albumImg}
        <div class="modal-album-info">
          <h2>${escHtml(album.name)}</h2>
          <p>${escHtml(artists)}</p>
          <p>${album.release_date?.slice(0, 4) || ''} · ${tracks.length} tracks</p>
          <a href="${spotifyUrl}" target="_blank" rel="noopener" class="spotify-link">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>
            Open in Spotify
          </a>
        </div>
      </div>
      <p class="modal-section-title">Tracks</p>
      <ul class="track-list">${trackRows}</ul>
    `);

    // Bind preview buttons
    $('#modalContent').querySelectorAll('.track-preview-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        playPreview(btn.dataset.preview, btn.dataset.id, album.name, btn.closest('.track-item').querySelector('.track-name').textContent, album.images?.[0]?.url);
      });
    });
  } catch (e) {
    openModal(`<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`);
  }
}

// ─── Playlist Modal ───────────────────────────────────────
async function showPlaylistModal(playlistId) {
  openModal('<div class="empty-state"><div class="empty-icon">⏳</div><p>Loading…</p></div>');
  try {
    const pl = await apiFetch(`/api/playlist/${playlistId}`);
    const plImg = pl.images?.length
      ? `<img src="${pl.images[0].url}" alt="${escHtml(pl.name)}" class="modal-playlist-img" />`
      : `<div class="modal-album-img-placeholder">🎧</div>`;

    const spotifyUrl = pl.external_urls?.spotify || '#';

    // Get tracks from the response
    const rawItems = pl.tracks?.items || [];
    const validTracks = rawItems
      .map(entry => entry.track || entry.item)
      .filter(t => t && t.id && t.name); // Filter out null/invalid tracks
    
    const trackRows = validTracks.slice(0, 30).map((t, i) => {
      const previewBtn = t.preview_url
        ? `<button class="track-preview-btn" data-preview="${t.preview_url}" data-id="${t.id}" aria-label="Preview">
             <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
           </button>`
        : '';
      return `
        <li class="track-item">
          <span class="track-num">${i + 1}</span>
          <div class="track-info">
            <div class="track-name">${escHtml(t.name)}</div>
            <div class="track-artist">${escHtml(t.artists?.map((a) => a.name).join(', ') || '')}</div>
          </div>
          <span class="track-duration">${fmtMs(t.duration_ms || 0)}</span>
          ${previewBtn}
        </li>`;
    }).join('');

    const totalTracks = pl.tracks?.total || validTracks.length;

    openModal(`
      <div class="modal-playlist-header">
        ${plImg}
        <div class="modal-playlist-info">
          <h2>${escHtml(pl.name)}</h2>
          <p>${escHtml(pl.description || '')}</p>
          <p>${totalTracks} tracks · by ${escHtml(pl.owner?.display_name || 'Spotify')}</p>
          <a href="${spotifyUrl}" target="_blank" rel="noopener" class="spotify-link">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>
            Open in Spotify
          </a>
        </div>
      </div>
      <p class="modal-section-title">Tracks (showing ${validTracks.length} of ${totalTracks})</p>
      <ul class="track-list">${trackRows || '<li style="color:var(--text-muted);padding:12px">No tracks available.</li>'}</ul>
    `);

    $('#modalContent').querySelectorAll('.track-preview-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const li = btn.closest('.track-item');
        playPreview(btn.dataset.preview, btn.dataset.id, pl.name, li.querySelector('.track-name').textContent, pl.images?.[0]?.url);
      });
    });
  } catch (e) {
    openModal(`<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`);
  }
}

// ─── Audio Preview Player ─────────────────────────────────
function buildPlayerBar() {
  const bar = document.createElement('div');
  bar.className = 'player-bar';
  bar.id = 'playerBar';
  bar.innerHTML = `
    <div class="player-track-info">
      <img src="" alt="" class="player-thumb" id="playerThumb" />
      <div>
        <div class="player-track-name" id="playerTrackName">—</div>
        <div class="player-track-artist" id="playerTrackArtist">—</div>
      </div>
    </div>
    <div class="player-controls">
      <div class="player-btns">
        <button class="player-btn" id="playerPrev" aria-label="Restart">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg>
        </button>
        <button class="player-btn play-pause" id="playerPlayPause" aria-label="Play/Pause">
          <svg viewBox="0 0 24 24" fill="currentColor" id="playPauseIcon"><path d="M8 5v14l11-7z"/></svg>
        </button>
        <button class="player-btn" id="playerStop" aria-label="Stop">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h12v12H6z"/></svg>
        </button>
      </div>
      <div class="player-progress">
        <span class="progress-time" id="progressCurrent">0:00</span>
        <div class="progress-bar" id="progressBar">
          <div class="progress-fill" id="progressFill"></div>
        </div>
        <span class="progress-time right" id="progressTotal">0:30</span>
      </div>
    </div>
    <div class="player-volume">
      <svg viewBox="0 0 24 24" fill="currentColor" style="width:18px;height:18px;color:var(--text-muted)">
        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/>
      </svg>
      <input type="range" class="volume-slider" id="volumeSlider" min="0" max="1" step="0.05" value="0.8" />
    </div>
  `;
  document.body.appendChild(bar);
}

function playPreview(previewUrl, trackId, albumName, trackName, thumbUrl) {
  if (!previewUrl) {
    showToast('No preview available for this track');
    return;
  }

  // Stop existing audio
  if (state.audio) {
    state.audio.pause();
    state.audio = null;
  }

  const bar = $('#playerBar');
  const audio = new Audio(previewUrl);
  audio.volume = parseFloat($('#volumeSlider').value);
  state.audio = audio;
  state.playingTrackId = trackId;

  // Update UI
  $('#playerThumb').src = thumbUrl || '';
  $('#playerTrackName').textContent = trackName;
  $('#playerTrackArtist').textContent = albumName;
  bar.classList.add('visible');
  updatePlayPauseIcon(false);

  audio.play().catch(() => showToast('Could not play preview'));

  audio.addEventListener('timeupdate', () => {
    const pct = (audio.currentTime / audio.duration) * 100 || 0;
    $('#progressFill').style.width = `${pct}%`;
    $('#progressCurrent').textContent = fmtMs(audio.currentTime * 1000);
    $('#progressTotal').textContent = fmtMs(audio.duration * 1000 || 30000);
  });

  audio.addEventListener('ended', () => {
    updatePlayPauseIcon(true);
    $('#progressFill').style.width = '0%';
  });

  audio.addEventListener('play', () => updatePlayPauseIcon(false));
  audio.addEventListener('pause', () => updatePlayPauseIcon(true));
}

function updatePlayPauseIcon(paused) {
  $('#playPauseIcon').innerHTML = paused
    ? '<path d="M8 5v14l11-7z"/>'
    : '<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>';
}

function initPlayerBar() {
  buildPlayerBar();

  $('#playerPlayPause').addEventListener('click', () => {
    if (!state.audio) return;
    state.audio.paused ? state.audio.play() : state.audio.pause();
  });

  $('#playerStop').addEventListener('click', () => {
    if (state.audio) { state.audio.pause(); state.audio.currentTime = 0; }
    $('#playerBar').classList.remove('visible');
  });

  $('#playerPrev').addEventListener('click', () => {
    if (state.audio) state.audio.currentTime = 0;
  });

  $('#volumeSlider').addEventListener('input', (e) => {
    if (state.audio) state.audio.volume = parseFloat(e.target.value);
  });

  $('#progressBar').addEventListener('click', (e) => {
    if (!state.audio) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    state.audio.currentTime = pct * state.audio.duration;
  });
}

// ─── Card Click Dispatcher ────────────────────────────────
function handleCardClick(el) {
  const type = el.dataset.type;
  const id = el.dataset.id;
  const preview = el.dataset.preview;

  if (type === 'track') {
    if (preview) {
      const name = el.querySelector('.card-title')?.textContent || '';
      const artist = el.querySelector('.card-sub')?.textContent || '';
      const thumb = el.querySelector('.card-img')?.src || '';
      playPreview(preview, id, artist, name, thumb);
    } else {
      showToast('No preview available for this track');
    }
  } else if (type === 'artist') {
    showArtistModal(id);
  } else if (type === 'album') {
    showAlbumModal(id);
  } else if (type === 'playlist') {
    showPlaylistModal(id);
  }
}

function bindCardClicks(container) {
  container.querySelectorAll('.card').forEach((card) => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('.card-play-btn')) return; // handled separately
      handleCardClick(card);
    });
    const playBtn = card.querySelector('.card-play-btn');
    if (playBtn) {
      playBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        handleCardClick(card);
      });
    }
  });
}

// ─── Search ───────────────────────────────────────────────
let searchDebounce = null;

function doSearch(offset = 0) {
  const q = state.searchQuery.trim();
  if (!q) return;

  state.searchOffset = offset;
  showView('search');
  $('#searchSubtitle').textContent = `Searching for "${q}"…`;
  $('#searchResults').innerHTML = Array(6).fill('<div class="skeleton-card"></div>').join('');
  $('#searchPagination').style.display = 'none';

  apiFetch(`/api/search?q=${encodeURIComponent(q)}&type=${state.searchType}&offset=${offset}`)
    .then((data) => {
      const key = `${state.searchType}s`;
      const results = data[key];
      if (!results || !results.items?.length) {
        $('#searchResults').innerHTML = `
          <div class="empty-state">
            <div class="empty-icon">🔍</div>
            <p>No ${state.searchType}s found for "${escHtml(q)}"</p>
          </div>`;
        return;
      }

      state.searchTotal = results.total;
      $('#searchSubtitle').textContent = `${results.total.toLocaleString()} results for "${q}"`;

      const cards = results.items.map((item) => {
        if (state.searchType === 'track') return buildTrackCard(item);
        if (state.searchType === 'artist') return buildArtistCard(item);
        if (state.searchType === 'album') return buildAlbumCard(item);
        return '';
      }).join('');

      $('#searchResults').innerHTML = cards;
      bindCardClicks($('#searchResults'));

      // Pagination
      const hasNext = offset + 10 < results.total;
      const hasPrev = offset > 0;
      if (hasNext || hasPrev) {
        $('#searchPagination').style.display = 'flex';
        const page = Math.floor(offset / 10) + 1;
        const totalPages = Math.ceil(results.total / 10);
        $('#pageInfo').textContent = `Page ${page} of ${totalPages}`;
        $('#prevPage').disabled = !hasPrev;
        $('#nextPage').disabled = !hasNext;
      }
    })
    .catch((e) => {
      $('#searchResults').innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <p>${escHtml(e.message)}</p>
        </div>`;
    });
}

// ─── Home: Featured Playlists ─────────────────────────────
function loadFeaturedPlaylists(containerId) {
  apiFetch('/api/featured-playlists')
    .then((data) => {
      const playlists = (data.playlists?.items || []).filter(pl => pl && pl.id);
      if (!playlists.length) {
        document.getElementById(containerId).innerHTML =
          '<div class="empty-state"><p>No featured playlists available.</p></div>';
        return;
      }
      document.getElementById(containerId).innerHTML = playlists.map(buildPlaylistCard).join('');
      bindCardClicks(document.getElementById(containerId));
    })
    .catch((e) => {
      document.getElementById(containerId).innerHTML =
        `<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`;
    });
}

// ─── Home: Genre Chips + Recommendations ─────────────────
const QUICK_GENRES = ['pop', 'rock', 'hip-hop', 'jazz', 'electronic', 'classical', 'r-n-b', 'indie', 'metal', 'latin'];

function loadGenreChips() {
  const container = $('#genreChips');
  container.innerHTML = QUICK_GENRES.map((g) =>
    `<button class="genre-chip" data-genre="${g}">${g}</button>`
  ).join('');

  container.querySelectorAll('.genre-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      container.querySelectorAll('.genre-chip').forEach((c) => c.classList.remove('active'));
      chip.classList.add('active');
      state.activeGenre = chip.dataset.genre;
      loadRecommendations('recommendedTracks', chip.dataset.genre);
    });
  });

  // Auto-load first genre
  container.querySelector('.genre-chip').classList.add('active');
  state.activeGenre = QUICK_GENRES[0];
  loadRecommendations('recommendedTracks', QUICK_GENRES[0]);
}

function loadRecommendations(containerId, genre) {
  const el = document.getElementById(containerId);
  el.innerHTML = Array(6).fill('<div class="skeleton-card"></div>').join('');

  apiFetch(`/api/recommendations?genres=${encodeURIComponent(genre)}`)
    .then((data) => {
      const tracks = data.tracks || [];
      if (!tracks.length) {
        el.innerHTML = '<div class="empty-state"><p>No recommendations found.</p></div>';
        return;
      }
      el.innerHTML = tracks.filter(t => t && t.id).map(buildTrackCard).join('');
      bindCardClicks(el);
    })
    .catch((e) => {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`;
    });
}

// ─── Playlists View ───────────────────────────────────────
function loadPlaylistsView() {
  const el = $('#playlistsGrid');
  if (el.children.length && !el.querySelector('.skeleton-card')) return; // already loaded
  el.innerHTML = Array(8).fill('<div class="skeleton-card"></div>').join('');

  apiFetch('/api/featured-playlists')
    .then((data) => {
      const playlists = (data.playlists?.items || []).filter(pl => pl && pl.id);
      el.innerHTML = playlists.map(buildPlaylistCard).join('');
      bindCardClicks(el);
    })
    .catch((e) => {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`;
    });
}

// ─── Discover View ────────────────────────────────────────
function loadGenreDropdown() {
  apiFetch('/api/genre-seeds')
    .then((data) => {
      const genres = data.genres || QUICK_GENRES;
      state.genreSeeds = genres;
      const sel = $('#genreSelect');
      sel.innerHTML = genres.map((g) => `<option value="${g}">${g}</option>`).join('');
    })
    .catch(() => {
      const sel = $('#genreSelect');
      sel.innerHTML = QUICK_GENRES.map((g) => `<option value="${g}">${g}</option>`).join('');
    });
}

function loadDiscoverResults(genre) {
  const el = $('#discoverResults');
  el.innerHTML = Array(8).fill('<div class="skeleton-card"></div>').join('');

  apiFetch(`/api/recommendations?genres=${encodeURIComponent(genre)}`)
    .then((data) => {
      const tracks = data.tracks || [];
      if (!tracks.length) {
        el.innerHTML = '<div class="empty-state"><p>No tracks found for this genre.</p></div>';
        return;
      }
      el.innerHTML = tracks.filter(t => t && t.id).map(buildTrackCard).join('');
      bindCardClicks(el);
    })
    .catch((e) => {
      el.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><p>${escHtml(e.message)}</p></div>`;
    });
}

// ─── Init ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setGreeting();
  initPlayerBar();

  // Nav buttons
  $$('.nav-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const view = btn.dataset.view;
      showView(view);
      if (view === 'playlists') loadPlaylistsView();
      if (view === 'discover') loadGenreDropdown();
    });
  });

  // Mobile menu toggle
  $('#menuToggle').addEventListener('click', () => {
    $('#sidebar').classList.toggle('open');
  });

  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', (e) => {
    if (window.innerWidth <= 768 &&
        !e.target.closest('#sidebar') &&
        !e.target.closest('#menuToggle')) {
      $('#sidebar').classList.remove('open');
    }
  });

  // Search input
  $('#searchInput').addEventListener('input', (e) => {
    state.searchQuery = e.target.value;
    clearTimeout(searchDebounce);
    if (state.searchQuery.trim().length >= 2) {
      searchDebounce = setTimeout(() => doSearch(0), 400);
    }
  });

  $('#searchInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      clearTimeout(searchDebounce);
      doSearch(0);
    }
  });

  // Search type tabs
  $$('.type-tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      $$('.type-tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      state.searchType = tab.dataset.type;
      if (state.searchQuery.trim()) doSearch(0);
    });
  });

  // Pagination
  $('#prevPage').addEventListener('click', () => doSearch(state.searchOffset - 10));
  $('#nextPage').addEventListener('click', () => doSearch(state.searchOffset + 10));

  // Modal close
  $('#modalClose').addEventListener('click', closeModal);
  $('#modalOverlay').addEventListener('click', (e) => {
    if (e.target === $('#modalOverlay')) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  // Discover button
  $('#discoverBtn').addEventListener('click', () => {
    const genre = $('#genreSelect').value;
    if (genre) loadDiscoverResults(genre);
  });

  // Load home data
  loadFeaturedPlaylists('featuredPlaylists');
  loadGenreChips();
});
