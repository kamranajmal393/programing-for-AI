# 🎵 Spotify Explorer

A dynamic Flask web app that lets you search artists, albums, and tracks using the Spotify Web API.

## Features

- 🔍 **Search** — Find tracks, artists, and albums with live search + pagination
- 🏠 **Home** — Featured playlists + genre-based recommendations
- 🎧 **Playlists** — Browse Spotify's curated featured playlists
- 🎲 **Discover** — Explore tracks by genre seed
- ▶️ **Preview Player** — 30-second audio previews with a mini player bar
- 📱 **Responsive** — Works on mobile and desktop

## Setup

### 1. Get Spotify API Credentials

1. Go to [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Log in and click **Create App**
3. Fill in the app name/description, set Redirect URI to `http://localhost:5000`
4. Copy your **Client ID** and **Client Secret**

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` and fill in your credentials:

```
SPOTIFY_CLIENT_ID=your_client_id_here
SPOTIFY_CLIENT_SECRET=your_client_secret_here
FLASK_SECRET_KEY=any_random_string
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the App

```bash
python app.py
```

Open [http://localhost:5000](http://localhost:5000) in your browser.

## Project Structure

```
spotify-app/
├── app.py                  # Flask backend + Spotify API routes
├── requirements.txt
├── .env.example
├── templates/
│   └── index.html          # Single-page app template
└── static/
    ├── css/
    │   └── style.css       # Dark Spotify-inspired theme
    └── js/
        └── app.js          # Dynamic frontend logic
```

## API Endpoints

| Route | Description |
|-------|-------------|
| `GET /api/search?q=&type=` | Search tracks/artists/albums |
| `GET /api/artist/<id>` | Artist details + albums |
| `GET /api/album/<id>` | Album details + tracks |
| `GET /api/track/<id>` | Single track details |
| `GET /api/featured-playlists` | Spotify featured playlists |
| `GET /api/playlist/<id>` | Playlist details + tracks |
| `GET /api/genre-seeds` | Available genre seeds |
| `GET /api/recommendations?genres=` | Track recommendations by genre |

## Notes

- Uses **Client Credentials** OAuth flow — no user login required
- Audio previews are 30-second clips provided by Spotify (not all tracks have them)
- The app respects Spotify's February 2026 API changes (updated field names, removed batch endpoints)
