import os
import base64
import time
import requests
from flask import Flask, render_template, request, jsonify, session
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-key-change-me")

SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_API_BASE = "https://api.spotify.com/v1"

# ─── Token Management ────────────────────────────────────────────────────────

_token_cache = {"access_token": None, "expires_at": 0}


def get_access_token():
    """Fetch or return a cached Client Credentials access token."""
    now = time.time()
    if _token_cache["access_token"] and now < _token_cache["expires_at"] - 30:
        return _token_cache["access_token"]

    credentials = f"{SPOTIFY_CLIENT_ID}:{SPOTIFY_CLIENT_SECRET}"
    encoded = base64.b64encode(credentials.encode()).decode()

    resp = requests.post(
        SPOTIFY_TOKEN_URL,
        headers={
            "Authorization": f"Basic {encoded}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={"grant_type": "client_credentials"},
        timeout=10,
    )
    resp.raise_for_status()
    data = resp.json()
    _token_cache["access_token"] = data["access_token"]
    _token_cache["expires_at"] = now + data["expires_in"]
    return _token_cache["access_token"]


def spotify_get(endpoint, params=None):
    """Make an authenticated GET request to the Spotify API."""
    token = get_access_token()
    resp = requests.get(
        f"{SPOTIFY_API_BASE}{endpoint}",
        headers={"Authorization": f"Bearer {token}"},
        params=params,
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/search")
def search():
    """Search for tracks, artists, or albums."""
    query = request.args.get("q", "").strip()
    search_type = request.args.get("type", "track")  # track | artist | album
    offset = int(request.args.get("offset", 0))

    if not query:
        return jsonify({"error": "Query is required"}), 400

    valid_types = {"track", "artist", "album"}
    if search_type not in valid_types:
        return jsonify({"error": "Invalid type"}), 400

    try:
        data = spotify_get(
            "/search",
            params={"q": query, "type": search_type, "limit": 10, "offset": offset},
        )
        return jsonify(data)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/artist/<artist_id>")
def artist_detail(artist_id):
    """Get artist details + their albums."""
    try:
        artist = spotify_get(f"/artists/{artist_id}")
        albums_data = spotify_get(
            f"/artists/{artist_id}/albums",
            params={"include_groups": "album,single", "limit": 10},
        )
        return jsonify({"artist": artist, "albums": albums_data})
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/album/<album_id>")
def album_detail(album_id):
    """Get album details + its tracks."""
    try:
        album = spotify_get(f"/albums/{album_id}")
        return jsonify(album)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/track/<track_id>")
def track_detail(track_id):
    """Get a single track's details."""
    try:
        track = spotify_get(f"/tracks/{track_id}")
        return jsonify(track)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/featured-playlists")
def featured_playlists():
    """Get Spotify featured playlists."""
    try:
        data = spotify_get("/browse/featured-playlists", params={"limit": 8})
        return jsonify(data)
    except requests.HTTPError as e:
        # Fallback: if featured playlists require user auth, return search results for popular playlists
        if e.response.status_code == 403:
            try:
                fallback = spotify_get("/search", params={"q": "Top Hits", "type": "playlist", "limit": 8})
                return jsonify({"playlists": fallback.get("playlists", {})})
            except:
                pass
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/playlist/<playlist_id>")
def playlist_detail(playlist_id):
    """Get playlist details and its items."""
    try:
        playlist = spotify_get(f"/playlists/{playlist_id}")
        # Debug: log the structure
        print(f"Playlist keys: {playlist.keys()}")
        if 'tracks' in playlist:
            print(f"Tracks keys: {playlist['tracks'].keys()}")
            print(f"Number of items: {len(playlist['tracks'].get('items', []))}")
        return jsonify(playlist)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/genre-seeds")
def genre_seeds():
    """Get available genre seeds for recommendations."""
    try:
        data = spotify_get("/recommendations/available-genre-seeds")
        return jsonify(data)
    except requests.HTTPError as e:
        # Fallback: return hardcoded popular genres
        if e.response.status_code in (403, 404):
            return jsonify({"genres": ["pop", "rock", "hip-hop", "jazz", "electronic", "classical", "r-n-b", "indie", "metal", "latin", "country", "blues", "reggae", "folk", "soul", "funk", "punk", "alternative", "dance", "edm"]})
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


@app.route("/api/recommendations")
def recommendations():
    """Get track recommendations based on seed genres."""
    genres = request.args.get("genres", "pop")
    try:
        data = spotify_get(
            "/recommendations",
            params={"seed_genres": genres, "limit": 10},
        )
        return jsonify(data)
    except requests.HTTPError as e:
        # Fallback: search for tracks in that genre instead
        if e.response.status_code in (403, 404):
            try:
                search_query = f"genre:{genres}" if genres else "top tracks"
                fallback = spotify_get("/search", params={"q": search_query, "type": "track", "limit": 10})
                return jsonify({"tracks": fallback.get("tracks", {}).get("items", [])})
            except:
                pass
        return jsonify({"error": str(e)}), e.response.status_code
    except Exception as e:
        return jsonify({"error": "Spotify API error", "detail": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
