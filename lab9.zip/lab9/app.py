from flask import Flask, render_template, request, jsonify
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import torch

app = Flask(__name__)

# Initialize the text generation model
# Using GPT-2 as it's lightweight and works well for demos
print("Loading model...")
model_name = "gpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Create text generation pipeline
generator = pipeline(
    'text-generation',
    model=model,
    tokenizer=tokenizer,
    device=0 if torch.cuda.is_available() else -1
)

print("Model loaded successfully!")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_text():
    try:
        data = request.json
        prompt = data.get('prompt', '')
        max_length = int(data.get('max_length', 100))
        temperature = float(data.get('temperature', 0.7))
        top_p = float(data.get('top_p', 0.9))
        repetition_penalty = float(data.get('repetition_penalty', 1.2))
        
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
        
        # Generate text with improved parameters
        result = generator(
            prompt,
            max_length=max_length,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            num_return_sequences=1,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id,
            no_repeat_ngram_size=3  # Prevent repeating 3-word sequences
        )
        
        generated_text = result[0]['generated_text']
        
        return jsonify({
            'success': True,
            'generated_text': generated_text,
            'prompt': prompt
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/models')
def get_models():
    """Return available models"""
    models = [
        {'name': 'GPT-2', 'id': 'gpt2', 'description': 'Small, fast text generation'},
        {'name': 'GPT-2 Medium', 'id': 'gpt2-medium', 'description': 'Better quality, slower'},
        {'name': 'DistilGPT-2', 'id': 'distilgpt2', 'description': 'Faster, lighter version'}
    ]
    return jsonify(models)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
