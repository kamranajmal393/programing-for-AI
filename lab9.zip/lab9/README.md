# AI Text Generator Web App

A modern web application for text generation using HuggingFace Transformers (GPT-2 model).

## Features

- 🤖 **AI-Powered Text Generation** using GPT-2 from HuggingFace
- 🎨 **Modern UI** with gradient design and smooth animations
- ⚙️ **Customizable Parameters**:
  - Max Length (50-500 tokens)
  - Temperature (0.1-1.5) - Controls randomness
  - Top P (0.1-1.0) - Nucleus sampling parameter
- 💡 **Example Prompts** for quick testing
- 📱 **Responsive Design** works on all devices

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Setup

1. **Install dependencies:**

```bash
pip install -r requirements.txt
```

2. **Run the application:**

```bash
python app.py
```

3. **Open your browser:**

Navigate to `http://localhost:5000`

## Usage

1. Enter a text prompt in the input field
2. Adjust the generation parameters using the sliders:
   - **Max Length**: How many tokens to generate
   - **Temperature**: Higher = more creative, Lower = more focused
   - **Top P**: Nucleus sampling threshold
3. Click "Generate Text" or use the example prompts
4. View the generated text in the output section

## How It Works

### Backend (Flask + HuggingFace)

- **Flask**: Lightweight web framework for the API
- **Transformers**: HuggingFace library for loading pre-trained models
- **GPT-2**: Generative Pre-trained Transformer for text generation
- **PyTorch**: Deep learning framework (backend for Transformers)

### Frontend

- **HTML/CSS**: Modern, responsive interface
- **JavaScript**: Async API calls and dynamic UI updates
- **Gradient Design**: Beautiful purple gradient theme

## API Endpoints

### `POST /generate`

Generate text based on a prompt.

**Request Body:**
```json
{
  "prompt": "Your text prompt",
  "max_length": 100,
  "temperature": 0.7,
  "top_p": 0.9
}
```

**Response:**
```json
{
  "success": true,
  "generated_text": "Generated text here...",
  "prompt": "Original prompt"
}
```

### `GET /models`

Get list of available models.

## Parameters Explained

- **Max Length**: Total length of generated text (including prompt)
- **Temperature**: 
  - Low (0.1-0.5): More deterministic, focused output
  - Medium (0.6-0.9): Balanced creativity
  - High (1.0-1.5): More random, creative output
- **Top P**: Nucleus sampling - considers tokens with cumulative probability up to P

## Customization

### Using Different Models

You can easily switch to other HuggingFace models by changing the `model_name` in `app.py`:

```python
# Options:
model_name = "gpt2"              # Small (124M parameters)
model_name = "gpt2-medium"       # Medium (355M parameters)
model_name = "gpt2-large"        # Large (774M parameters)
model_name = "distilgpt2"        # Distilled version (faster)
```

### Styling

Modify the CSS in `templates/index.html` to customize colors, fonts, and layout.

## Performance Tips

- First generation may be slow as the model loads
- GPU acceleration is automatic if CUDA is available
- Use `distilgpt2` for faster inference on CPU
- Reduce `max_length` for quicker responses

## Troubleshooting

**Model loading is slow:**
- First run downloads the model (~500MB for GPT-2)
- Subsequent runs load from cache

**Out of memory:**
- Use a smaller model like `distilgpt2`
- Reduce `max_length`
- Close other applications

**Port already in use:**
- Change the port in `app.py`: `app.run(port=5001)`

## Technologies Used

- **Backend**: Python, Flask, HuggingFace Transformers, PyTorch
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **AI Model**: GPT-2 (Generative Pre-trained Transformer)

## License

MIT License - Feel free to use and modify!

## Future Enhancements

- [ ] Model selection dropdown
- [ ] Save/export generated text
- [ ] Multiple generation variants
- [ ] Fine-tuning interface
- [ ] LSTM and FNet implementations
- [ ] Batch generation
- [ ] API key for production deployment

## Contributing

Feel free to submit issues and enhancement requests!
