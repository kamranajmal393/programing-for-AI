const chatWindow = document.getElementById('chatWindow');
const userInput  = document.getElementById('userInput');
const sendBtn    = document.getElementById('sendBtn');

// ── Helpers ──────────────────────────────────────────────────────────────────

function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function appendMessage(text, sender) {
  const wrapper = document.createElement('div');
  wrapper.classList.add('message', sender);

  const avatar = document.createElement('div');
  avatar.classList.add('avatar');
  avatar.textContent = sender === 'bot' ? '🏨' : '👤';

  const bubble = document.createElement('div');
  bubble.classList.add('bubble');
  bubble.innerHTML = text;   // allows HTML from server

  wrapper.appendChild(avatar);
  wrapper.appendChild(bubble);
  chatWindow.appendChild(wrapper);
  scrollToBottom();
}

function showTyping() {
  const wrapper = document.createElement('div');
  wrapper.classList.add('message', 'bot');
  wrapper.id = 'typingIndicator';

  const avatar = document.createElement('div');
  avatar.classList.add('avatar');
  avatar.textContent = '🏨';

  const bubble = document.createElement('div');
  bubble.classList.add('bubble', 'typing-indicator');
  bubble.innerHTML = '<span></span><span></span><span></span>';

  wrapper.appendChild(avatar);
  wrapper.appendChild(bubble);
  chatWindow.appendChild(wrapper);
  scrollToBottom();
}

function removeTyping() {
  const el = document.getElementById('typingIndicator');
  if (el) el.remove();
}

// ── Send message ─────────────────────────────────────────────────────────────

async function sendMessage(text) {
  const message = (text || userInput.value).trim();
  if (!message) return;

  userInput.value = '';
  sendBtn.disabled = true;

  appendMessage(message, 'user');
  showTyping();

  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });

    const data = await res.json();
    removeTyping();
    appendMessage(data.response, 'bot');
  } catch (err) {
    removeTyping();
    appendMessage('Sorry, I\'m having trouble connecting. Please try again. 🙏', 'bot');
  } finally {
    sendBtn.disabled = false;
    userInput.focus();
  }
}

// ── Event listeners ───────────────────────────────────────────────────────────

sendBtn.addEventListener('click', () => sendMessage());

userInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Quick-topic buttons
document.querySelectorAll('.quick-btn').forEach((btn) => {
  btn.addEventListener('click', () => sendMessage(btn.dataset.msg));
});

// ── Welcome message on load ───────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    appendMessage(
      'Welcome to <strong>Grand Azure Hotel</strong>! 🏨<br>' +
      'I\'m your virtual concierge. I can help you with:<br><br>' +
      '🛏️ Room types &amp; prices<br>' +
      '📅 Check-in / check-out times<br>' +
      '🏊 Amenities (pool, spa, gym, restaurant…)<br>' +
      '📋 Hotel policies<br>' +
      '📍 Location &amp; nearby attractions<br>' +
      '📞 Contact &amp; booking info<br><br>' +
      'What can I help you with today?',
      'bot'
    );
  }, 400);
});
