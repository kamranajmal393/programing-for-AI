# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

# ─────────────────────────────────────────────
#  Knowledge base
# ─────────────────────────────────────────────
HOTEL_DATA = {
    "name": "Grand Azure Hotel",
    "address": "123 Ocean Boulevard, Miami, FL 33101",
    "phone": "+1 (305) 555-0199",
    "email": "reservations@grandazure.com",
    "check_in": "3:00 PM",
    "check_out": "11:00 AM",
    "rooms": {
        "standard": {
            "name": "Standard Room",
            "price": "$120/night",
            "beds": "1 Queen Bed",
            "size": "280 sq ft",
            "amenities": ["Free Wi-Fi", "Flat-screen TV", "Air conditioning", "Mini fridge", "Safe"],
        },
        "deluxe": {
            "name": "Deluxe Room",
            "price": "$180/night",
            "beds": "1 King Bed",
            "size": "380 sq ft",
            "amenities": ["Free Wi-Fi", "55\" Smart TV", "Air conditioning", "Mini bar", "Safe", "City view", "Bathrobe & slippers"],
        },
        "suite": {
            "name": "Junior Suite",
            "price": "$280/night",
            "beds": "1 King Bed + Sofa bed",
            "size": "550 sq ft",
            "amenities": ["Free Wi-Fi", "65\" Smart TV", "Separate living area", "Jacuzzi", "Mini bar", "Ocean view", "Butler service"],
        },
        "penthouse": {
            "name": "Penthouse Suite",
            "price": "$650/night",
            "beds": "2 King Beds",
            "size": "1200 sq ft",
            "amenities": ["Free Wi-Fi", "Private terrace", "Private pool", "Full kitchen", "Butler service", "Panoramic ocean view", "Limousine pickup"],
        },
    },
    "amenities": {
        "pool": "Outdoor infinity pool open 7:00 AM – 10:00 PM",
        "spa": "Full-service spa open 9:00 AM – 8:00 PM. Services include massages, facials, and body treatments.",
        "gym": "24-hour fitness center with modern equipment",
        "restaurant": "Azure Dining — open for breakfast (7–10 AM), lunch (12–3 PM), and dinner (6–10 PM)",
        "bar": "Rooftop Sky Bar open 4:00 PM – 1:00 AM",
        "parking": "Valet parking available at $25/night. Self-parking at $15/night.",
        "wifi": "Complimentary high-speed Wi-Fi throughout the hotel",
        "concierge": "24-hour concierge service available at the front desk",
        "laundry": "Same-day laundry and dry-cleaning service available",
        "business": "Business center open 24/7 with printing and meeting rooms",
    },
    "policies": {
        "pets": "Pets are welcome! Pet fee: $50/night. Max weight: 30 lbs.",
        "smoking": "Grand Azure is a non-smoking property. Designated smoking areas are available outside.",
        "cancellation": "Free cancellation up to 48 hours before check-in. Late cancellations incur a 1-night charge.",
        "children": "Children under 12 stay free when sharing a room with parents.",
        "payment": "We accept Visa, MasterCard, American Express, and cash. A credit card is required at check-in.",
    },
    "nearby": [
        "South Beach — 0.5 miles",
        "Miami Art Museum — 1.2 miles",
        "Bayside Marketplace — 2.0 miles",
        "Miami International Airport — 8.5 miles",
    ],
}

# ─────────────────────────────────────────────
#  Intent matching
# ─────────────────────────────────────────────
def detect_intent(message: str) -> str:
    msg = message.lower()

    # Order matters: more specific patterns first
    patterns = [
        ("greeting",     r"\b(hi|hello|hey|good morning|good evening|good afternoon|howdy)\b"),
        ("farewell",     r"\b(bye|goodbye|see you|take care|thanks? bye|thank you bye)\b"),
        ("thanks",       r"\b(thank(s| you)|thx|cheers)\b"),
        ("checkin",      r"\b(check.?in|arrival|arrive)\b"),
        ("checkout",     r"\b(check.?out|departure|depart|leave)\b"),
        ("price",        r"\b(price|cost|rate|how much|fee|charge|expensive|cheap|afford)\b"),
        ("booking",      r"\b(book(ing)?|reserv(e|ation)?|availability|available)\b"),
        ("pool",         r"\b(pool|swim(ming)?)\b"),
        ("spa",          r"\b(spa|massage|facial|treatment|relax|wellness)\b"),
        ("gym",          r"\b(gym|fitness|workout|exercise)\b"),
        ("restaurant",   r"\b(restaurant|dining|breakfast|lunch|dinner|meal)\b"),
        ("bar",          r"\b(bar|cocktail|rooftop)\b"),
        ("parking",      r"\b(park(ing)?|valet)\b"),
        ("wifi",         r"\b(wi.?fi|internet|wireless)\b"),
        ("pets",         r"\b(pets?|dogs?|cats?|animals?)\b"),
        ("smoking",      r"\b(smok(ing|e)?|cigarette|tobacco)\b"),
        ("cancellation", r"\b(cancel(lation)?|refund)\b"),
        ("children",     r"\b(child(ren)?|kids?|baby|infant|family)\b"),
        ("payment",      r"\b(pay(ment)?|credit card|cash|visa|mastercard)\b"),
        ("location",     r"\b(location|address|where|direction|map|nearby|distance)\b"),
        ("contact",      r"\b(contact|phone|email|call|reach|number)\b"),
        ("amenities",    r"\b(amenities|facilities|features?|services?|offer)\b"),
        ("concierge",    r"\b(concierge|front desk)\b"),
        ("laundry",      r"\b(laundry|dry.?clean|wash|iron)\b"),
        ("business",     r"\b(business center|meeting room|conference|print)\b"),
        ("rooms",        r"\b(rooms?|accommodation|stay|suite|penthouse|deluxe|standard)\b"),
    ]

    for intent, pattern in patterns:
        if re.search(pattern, msg):
            return intent

    return "unknown"


# ─────────────────────────────────────────────
#  Response builder
# ─────────────────────────────────────────────
def build_response(intent: str, message: str) -> str:
    h = HOTEL_DATA

    if intent == "greeting":
        return (
            f"Welcome to <strong>{h['name']}</strong>! 🏨<br>"
            "I'm your virtual concierge. I can help you with:<br><br>"
            "🛏️ Room types &amp; prices<br>"
            "📅 Check-in / check-out times<br>"
            "🏊 Amenities (pool, spa, gym, restaurant…)<br>"
            "📋 Hotel policies<br>"
            "📍 Location &amp; nearby attractions<br>"
            "📞 Contact &amp; booking info<br><br>"
            "What can I help you with today?"
        )

    if intent == "farewell":
        return "Thank you for choosing <strong>Grand Azure Hotel</strong>! We look forward to welcoming you. Have a wonderful day! 🌟"

    if intent == "thanks":
        return "You're very welcome! Is there anything else I can help you with? 😊"

    if intent == "rooms":
        lines = ["Here are our available room types:<br><br>"]
        for key, r in h["rooms"].items():
            lines.append(
                f"🛏️ <strong>{r['name']}</strong><br>"
                f"&nbsp;&nbsp;• Price: {r['price']}<br>"
                f"&nbsp;&nbsp;• Beds: {r['beds']}<br>"
                f"&nbsp;&nbsp;• Size: {r['size']}<br><br>"
            )
        lines.append("Would you like details about a specific room type?")
        return "".join(lines)

    if intent == "price":
        lines = ["Here's our pricing overview:<br><br>"]
        for r in h["rooms"].values():
            lines.append(f"🏷️ <strong>{r['name']}</strong>: {r['price']}<br>")
        lines.append("<br>Prices may vary by season. Would you like to make a reservation?")
        return "".join(lines)

    if intent == "checkin":
        return f"✅ <strong>Check-in time</strong> is <strong>{h['check_in']}</strong>.<br>Early check-in may be available upon request (subject to availability). Please contact us at {h['phone']}."

    if intent == "checkout":
        return f"🚪 <strong>Check-out time</strong> is <strong>{h['check_out']}</strong>.<br>Late check-out can be arranged for an additional fee. Please speak with our front desk."

    if intent == "pool":
        return f"🏊 <strong>Pool:</strong> {h['amenities']['pool']}<br><br>Our infinity pool overlooks the ocean — perfect for a relaxing swim!"

    if intent == "spa":
        return f"💆 <strong>Spa &amp; Wellness:</strong> {h['amenities']['spa']}<br><br>Advance booking is recommended. Call {h['phone']} or ask our concierge."

    if intent == "gym":
        return f"💪 <strong>Fitness Center:</strong> {h['amenities']['gym']}<br><br>Complimentary for all hotel guests. Towels and lockers are provided."

    if intent == "restaurant":
        return (
            f"🍽️ <strong>Azure Dining</strong><br>"
            f"{h['amenities']['restaurant']}<br><br>"
            "Our menu features fresh seafood, international cuisine, and local Florida specialties. "
            "Reservations are recommended for dinner."
        )

    if intent == "bar":
        return f"🍹 <strong>Sky Bar:</strong> {h['amenities']['bar']}<br><br>Enjoy craft cocktails and stunning panoramic views of Miami. Live DJ on Friday &amp; Saturday nights!"

    if intent == "parking":
        return f"🚗 <strong>Parking:</strong> {h['amenities']['parking']}"

    if intent == "wifi":
        return f"📶 <strong>Wi-Fi:</strong> {h['amenities']['wifi']}<br><br>Network: <em>GrandAzure_Guest</em> — no password required."

    if intent == "pets":
        return f"🐾 <strong>Pet Policy:</strong> {h['policies']['pets']}"

    if intent == "smoking":
        return f"🚭 <strong>Smoking Policy:</strong> {h['policies']['smoking']}"

    if intent == "cancellation":
        return f"📋 <strong>Cancellation Policy:</strong> {h['policies']['cancellation']}"

    if intent == "children":
        return f"👨‍👩‍👧 <strong>Children Policy:</strong> {h['policies']['children']}<br><br>We also offer cribs and high chairs upon request."

    if intent == "payment":
        return f"💳 <strong>Payment:</strong> {h['policies']['payment']}"

    if intent == "location":
        nearby = "<br>".join(f"📍 {place}" for place in h["nearby"])
        return (
            f"🗺️ <strong>Address:</strong> {h['address']}<br><br>"
            f"<strong>Nearby Attractions:</strong><br>{nearby}"
        )

    if intent == "contact":
        return (
            f"📞 <strong>Phone:</strong> {h['phone']}<br>"
            f"📧 <strong>Email:</strong> {h['email']}<br>"
            f"🏨 <strong>Address:</strong> {h['address']}<br><br>"
            "Our front desk is available 24/7!"
        )

    if intent == "booking":
        return (
            "📅 <strong>To make a reservation:</strong><br><br>"
            f"📞 Call us: {h['phone']}<br>"
            f"📧 Email: {h['email']}<br>"
            "🌐 Or visit our website at <em>www.grandazure.com</em><br><br>"
            f"Check-in: <strong>{h['check_in']}</strong> &nbsp;|&nbsp; Check-out: <strong>{h['check_out']}</strong><br><br>"
            "Would you like to know about room availability or pricing?"
        )

    if intent == "amenities":
        lines = [f"✨ <strong>{h['name']}</strong> offers the following amenities:<br><br>"]
        icons = {"pool": "🏊", "spa": "💆", "gym": "💪", "restaurant": "🍽️",
                 "bar": "🍹", "parking": "🚗", "wifi": "📶", "concierge": "🛎️",
                 "laundry": "👔", "business": "💼"}
        for key, desc in h["amenities"].items():
            icon = icons.get(key, "•")
            lines.append(f"{icon} <strong>{key.capitalize()}:</strong> {desc}<br>")
        return "".join(lines)

    if intent == "concierge":
        return f"🛎️ <strong>Concierge:</strong> {h['amenities']['concierge']}<br><br>They can assist with tours, restaurant reservations, transportation, and more!"

    if intent == "laundry":
        return f"👔 <strong>Laundry:</strong> {h['amenities']['laundry']}<br><br>Drop off before 9:00 AM for same-day return."

    if intent == "business":
        return f"💼 <strong>Business Center:</strong> {h['amenities']['business']}<br><br>Meeting rooms can be reserved through the front desk."

    # Fallback
    return (
        "I'm not sure I understood that. Here are some things I can help with:<br><br>"
        "🛏️ <strong>Rooms</strong> — types, prices, amenities<br>"
        "📅 <strong>Check-in/out</strong> — times and policies<br>"
        "🏊 <strong>Amenities</strong> — pool, spa, gym, restaurant<br>"
        "📋 <strong>Policies</strong> — pets, smoking, cancellation<br>"
        "📍 <strong>Location</strong> — address and nearby attractions<br>"
        "📞 <strong>Contact</strong> — phone and email<br>"
        "📅 <strong>Booking</strong> — how to reserve a room<br><br>"
        "Try asking something like: <em>\"What rooms do you have?\"</em> or <em>\"How do I book a room?\"</em>"
    )


# ─────────────────────────────────────────────
#  Routes
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html", hotel_name=HOTEL_DATA["name"])


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"response": "Please type a message so I can help you! 😊"})

    intent = detect_intent(user_message)
    response = build_response(intent, user_message)

    return jsonify({"response": response, "intent": intent})


if __name__ == "__main__":
    app.run(debug=True)
