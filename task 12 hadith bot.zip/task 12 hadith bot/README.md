# Lab 10 — QnA Bot: Islamic Knowledge Bot

A semantic QnA chatbot built with **Hugging Face MiniLM**, **FAISS**, and **Flask**.

---

## Project Structure

```
├── HadithBot.ipynb          ← Task 1: Reference notebook (run in Jupyter)
├── README.md
└── qna_bot/
    ├── dataset.py           ← 25 Islamic QnA pairs (your dataset)
    ├── preprocess.py        ← Text cleaning & normalization
    ├── embedder.py          ← MiniLM embeddings + FAISS index
    ├── build_index.py       ← One-time index builder script
    ├── app.py               ← Flask web application
    ├── requirements.txt     ← Python dependencies
    └── templates/
        └── index.html       ← Chat UI (HTML + CSS + JS)
```

---

## Pipeline Overview

```
Dataset (dataset.py)
    ↓
Preprocess (preprocess.py)   — lowercase, clean whitespace
    ↓
Embed (embedder.py)          — MiniLM → 384-dim float32 vectors
    ↓
FAISS Index (embedder.py)    — IndexFlatL2, stored to disk
    ↓
Flask API (app.py)           — POST /ask → similarity search
    ↓
HTML UI (templates/index.html) — Chat interface
```

---

## Setup & Run

### 1. Install dependencies

```bash
pip install -r qna_bot/requirements.txt
```

### 2. Build the FAISS index (first time only)

```bash
python qna_bot/build_index.py
```

### 3. Start the Flask server

```bash
python qna_bot/app.py
```

### 4. Open in browser

```
http://127.0.0.1:5000
```

---

## Task 1 — HadithBot.ipynb

Open and run `HadithBot.ipynb` in Jupyter Notebook or JupyterLab:

```bash
jupyter notebook HadithBot.ipynb
```

The notebook walks through:
1. Loading a Hadith QnA dataset
2. Embedding with MiniLM
3. Building a FAISS index
4. Semantic search queries

---

## Features

- **Semantic search** — finds answers even when wording differs from dataset
- **Top-3 results** — shows best match + expandable additional results
- **Similarity score** — displayed for each result
- **Suggestion chips** — quick-start example queries
- **Typing indicator** — smooth UX while searching
- **Cached index** — FAISS index saved to disk, loaded on restart

---

## Dataset Topic

**Islamic History & Teachings** — 25 QnA pairs covering:
- Five Pillars of Islam
- Hadith & Sunnah
- Quran & Islamic beliefs
- Islamic history (Hijra, Battle of Badr, Caliphs)
- Ethics & daily life (patience, forgiveness, halal, Friday prayer)
