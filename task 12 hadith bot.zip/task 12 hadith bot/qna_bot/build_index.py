"""
build_index.py — One-time script to build and save the FAISS index.
Run this before starting the Flask app for the first time.

Usage:
    python qna_bot/build_index.py
"""

from dataset import QNA_DATA
from preprocess import preprocess_dataset, get_questions
from embedder import load_model, embed_questions, build_faiss_index, save_index

if __name__ == "__main__":
    print("=" * 50)
    print("  Building FAISS Index for Islamic QnA Bot")
    print("=" * 50)

    # Step 1: Preprocess
    print("\n[1/4] Preprocessing dataset...")
    processed = preprocess_dataset(QNA_DATA)
    print(f"      {len(processed)} QnA pairs ready.")

    # Step 2: Load model
    print("\n[2/4] Loading MiniLM model...")
    model = load_model()

    # Step 3: Embed
    print("\n[3/4] Embedding questions...")
    questions = get_questions(processed)
    embeddings = embed_questions(model, questions)

    # Step 4: Build & save FAISS index
    print("\n[4/4] Building and saving FAISS index...")
    index = build_faiss_index(embeddings)
    save_index(index, processed)

    print("\n✅ Done! Index saved. You can now run: python qna_bot/app.py")
