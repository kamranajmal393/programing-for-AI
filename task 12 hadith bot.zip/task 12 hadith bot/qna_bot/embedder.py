"""
embedder.py — Embed questions using Hugging Face MiniLM + store in FAISS
"""

import numpy as np
import faiss
import pickle
import os
from sentence_transformers import SentenceTransformer

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
INDEX_PATH = "qna_bot/faiss_index.bin"
DATA_PATH  = "qna_bot/qna_data.pkl"


def load_model() -> SentenceTransformer:
    """Load the MiniLM sentence transformer model."""
    print(f"[Embedder] Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)
    print("[Embedder] Model loaded.")
    return model


def embed_questions(model: SentenceTransformer, questions: list) -> np.ndarray:
    """Encode a list of questions into float32 embeddings."""
    print(f"[Embedder] Encoding {len(questions)} questions...")
    embeddings = model.encode(questions, show_progress_bar=True)
    embeddings = np.array(embeddings).astype("float32")
    print(f"[Embedder] Embeddings shape: {embeddings.shape}")
    return embeddings


def build_faiss_index(embeddings: np.ndarray) -> faiss.IndexFlatL2:
    """Build a FAISS flat L2 index from embeddings."""
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    print(f"[FAISS] Index built: {index.ntotal} vectors, dim={dimension}")
    return index


def save_index(index: faiss.IndexFlatL2, data: list):
    """Persist FAISS index and QnA data to disk."""
    faiss.write_index(index, INDEX_PATH)
    with open(DATA_PATH, "wb") as f:
        pickle.dump(data, f)
    print(f"[Embedder] Saved index → {INDEX_PATH}")
    print(f"[Embedder] Saved data  → {DATA_PATH}")


def load_index():
    """Load FAISS index and QnA data from disk."""
    if not os.path.exists(INDEX_PATH) or not os.path.exists(DATA_PATH):
        return None, None
    index = faiss.read_index(INDEX_PATH)
    with open(DATA_PATH, "rb") as f:
        data = pickle.load(f)
    print(f"[Embedder] Loaded index with {index.ntotal} vectors")
    return index, data


def search(model: SentenceTransformer, index: faiss.IndexFlatL2,
           data: list, query: str, top_k: int = 3) -> list:
    """
    Search FAISS index for the most similar questions to the query.
    Returns a list of dicts with question, answer, and distance.
    """
    query_embedding = model.encode([query]).astype("float32")
    distances, indices = index.search(query_embedding, top_k)

    results = []
    for rank, (idx, dist) in enumerate(zip(indices[0], distances[0])):
        results.append({
            "rank": rank + 1,
            "question": data[idx]["question"],
            "answer": data[idx]["answer"],
            "distance": float(dist),
            "similarity_score": round(1 / (1 + float(dist)), 4)  # normalized score
        })
    return results


if __name__ == "__main__":
    from dataset import QNA_DATA
    from preprocess import preprocess_dataset, get_questions

    processed = preprocess_dataset(QNA_DATA)
    questions = get_questions(processed)

    model = load_model()
    embeddings = embed_questions(model, questions)
    index = build_faiss_index(embeddings)
    save_index(index, processed)

    # Quick test
    results = search(model, index, processed, "What is prayer in Islam?")
    print("\n--- Test Search ---")
    for r in results:
        print(f"Rank {r['rank']}: {r['question']} (score={r['similarity_score']})")
        print(f"  → {r['answer'][:100]}...")
