"""
app.py — Flask web application for the Islamic Knowledge QnA Bot
"""

import os
from flask import Flask, render_template, request, jsonify

from dataset import QNA_DATA
from preprocess import preprocess_dataset, get_questions
from embedder import (
    load_model, embed_questions, build_faiss_index,
    save_index, load_index, search
)

app = Flask(__name__)

# ── Global state ──────────────────────────────────────────────────────────────
model = None
faiss_index = None
qna_data = None


def initialize():
    """Load or build the FAISS index on startup."""
    global model, faiss_index, qna_data

    model = load_model()

    # Try loading cached index first
    faiss_index, qna_data = load_index()

    if faiss_index is None:
        print("[App] No cached index found — building from scratch...")
        processed = preprocess_dataset(QNA_DATA)
        questions = get_questions(processed)
        embeddings = embed_questions(model, questions)
        faiss_index = build_faiss_index(embeddings)
        save_index(faiss_index, processed)
        qna_data = processed
    else:
        print("[App] Loaded cached FAISS index.")


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Render the main chat UI."""
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    """
    POST /ask
    Body: { "query": "..." }
    Returns: JSON list of top results
    """
    data = request.get_json()
    if not data or "query" not in data:
        return jsonify({"error": "Missing 'query' field"}), 400

    query = data["query"].strip()
    if not query:
        return jsonify({"error": "Query cannot be empty"}), 400

    top_k = int(data.get("top_k", 3))
    results = search(model, faiss_index, qna_data, query, top_k=top_k)
    return jsonify({"query": query, "results": results})


@app.route("/health")
def health():
    return jsonify({"status": "ok", "total_qna": len(qna_data) if qna_data else 0})


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    initialize()
    print("\n[App] Starting Flask server at http://127.0.0.1:5000\n")
    app.run(debug=True, use_reloader=False)
