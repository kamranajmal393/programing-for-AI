"""
preprocess.py — Text preprocessing for QnA dataset
"""

import re
import string


def clean_text(text: str) -> str:
    """
    Clean and normalize text:
    - Lowercase
    - Remove extra whitespace
    - Remove special characters (keep punctuation for readability)
    """
    if not text:
        return ""
    # Lowercase
    text = text.lower()
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def preprocess_dataset(data: list) -> list:
    """
    Preprocess a list of QnA dicts.
    Returns cleaned list with original + cleaned fields.
    """
    processed = []
    for item in data:
        processed.append({
            "question": item["question"],
            "answer": item["answer"],
            "question_clean": clean_text(item["question"]),
            "answer_clean": clean_text(item["answer"])
        })
    return processed


def get_questions(processed_data: list) -> list:
    """Extract list of original questions."""
    return [item["question"] for item in processed_data]


def get_answers(processed_data: list) -> list:
    """Extract list of original answers."""
    return [item["answer"] for item in processed_data]


if __name__ == "__main__":
    from dataset import QNA_DATA
    processed = preprocess_dataset(QNA_DATA)
    print(f"Preprocessed {len(processed)} QnA pairs")
    print("\nSample:")
    print(f"  Q: {processed[0]['question']}")
    print(f"  Q (clean): {processed[0]['question_clean']}")
    print(f"  A: {processed[0]['answer'][:80]}...")
