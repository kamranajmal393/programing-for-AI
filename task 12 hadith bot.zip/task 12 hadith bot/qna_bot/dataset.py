"""
dataset.py — QnA dataset for the Islamic Knowledge Bot
Topic: Islamic History & Teachings (Lab 10 topic)
"""

QNA_DATA = [
    # Pillars of Islam
    {
        "question": "What is the first pillar of Islam?",
        "answer": "The first pillar of Islam is the Shahada (declaration of faith): 'There is no god but Allah, and Muhammad is His messenger.' It is the foundation of Islamic belief."
    },
    {
        "question": "How many times a day do Muslims pray?",
        "answer": "Muslims pray five times a day: Fajr (dawn), Dhuhr (midday), Asr (afternoon), Maghrib (sunset), and Isha (night). Prayer is the second pillar of Islam."
    },
    {
        "question": "What is Zakat in Islam?",
        "answer": "Zakat is the obligatory almsgiving and the third pillar of Islam. Muslims who meet the nisab (minimum wealth threshold) must give 2.5% of their savings annually to those in need."
    },
    {
        "question": "What is the significance of Ramadan?",
        "answer": "Ramadan is the ninth month of the Islamic calendar during which Muslims fast from dawn to sunset. It commemorates the first revelation of the Quran to Prophet Muhammad (PBUH) and is the fourth pillar of Islam."
    },
    {
        "question": "What is Hajj?",
        "answer": "Hajj is the annual Islamic pilgrimage to Mecca, Saudi Arabia. It is the fifth pillar of Islam and is obligatory for every Muslim who is physically and financially able to perform it at least once in their lifetime."
    },

    # Hadith & Sunnah
    {
        "question": "What does the Hadith say about cleanliness?",
        "answer": "The Prophet Muhammad (PBUH) said: 'Cleanliness is half of faith.' (Sahih Muslim). Maintaining physical and spiritual purity is highly emphasized in Islam."
    },
    {
        "question": "What is the importance of honesty in Islam?",
        "answer": "The Prophet (PBUH) said: 'Truthfulness leads to righteousness and righteousness leads to Paradise.' (Bukhari & Muslim). Honesty is a core virtue in Islam."
    },
    {
        "question": "What is the Sunnah?",
        "answer": "The Sunnah refers to the practices, sayings, and approvals of Prophet Muhammad (PBUH). It is the second source of Islamic law after the Quran and guides Muslims in all aspects of life."
    },
    {
        "question": "What does Islam say about seeking knowledge?",
        "answer": "The Prophet (PBUH) said: 'Seeking knowledge is an obligation upon every Muslim.' (Ibn Majah). Islam places great emphasis on education, learning, and intellectual growth."
    },
    {
        "question": "What does Islam say about kindness to parents?",
        "answer": "The Quran commands: 'Your Lord has decreed that you worship none but Him, and that you be kind to parents.' (17:23). The Prophet also said Paradise lies at the feet of mothers."
    },

    # Quran & Beliefs
    {
        "question": "What is the Quran?",
        "answer": "The Quran is the holy book of Islam, believed to be the word of Allah as revealed to Prophet Muhammad (PBUH) through the angel Jibreel over 23 years. It contains 114 chapters (Surahs)."
    },
    {
        "question": "What is the Night of Power Laylat al-Qadr?",
        "answer": "Laylat al-Qadr is the Night of Power, occurring in the last ten nights of Ramadan. The Quran states it is better than a thousand months (97:3). Muslims spend this night in prayer and worship."
    },
    {
        "question": "What is the meaning of Jihad?",
        "answer": "Jihad means 'struggle' or 'striving'. The greater Jihad is the internal struggle against one's own ego and desires. The lesser Jihad refers to defending the Muslim community when necessary."
    },
    {
        "question": "What is the concept of Tawakkul?",
        "answer": "Tawakkul means complete trust and reliance on Allah. The Prophet (PBUH) said: 'If you were to rely upon Allah with the reliance He is due, He would provide for you as He provides for the birds.' (Tirmidhi)"
    },
    {
        "question": "What is the Islamic view on charity?",
        "answer": "Islam strongly encourages charity (Sadaqah). The Prophet (PBUH) said: 'The best of people are those who are most beneficial to others.' Charity purifies wealth and earns Allah's reward."
    },

    # Islamic History
    {
        "question": "When was Islam founded?",
        "answer": "Islam was founded in 610 CE when Prophet Muhammad (PBUH) received the first revelation in the Cave of Hira near Mecca. The Islamic calendar (Hijri) begins in 622 CE with the migration (Hijra) to Medina."
    },
    {
        "question": "Who was the first Caliph of Islam?",
        "answer": "Abu Bakr As-Siddiq (RA) was the first Caliph of Islam after the death of Prophet Muhammad (PBUH) in 632 CE. He was the Prophet's closest companion and father-in-law."
    },
    {
        "question": "What is the Battle of Badr?",
        "answer": "The Battle of Badr (624 CE) was the first major battle in Islamic history. Despite being outnumbered, the Muslim army of 313 defeated the Quraysh army of about 1,000. It is considered a decisive victory for the early Muslim community."
    },
    {
        "question": "What is the significance of the Hijra?",
        "answer": "The Hijra refers to the migration of Prophet Muhammad (PBUH) and his followers from Mecca to Medina in 622 CE. It marks the beginning of the Islamic calendar and was a turning point in establishing the Muslim community."
    },
    {
        "question": "Who built the Kaaba?",
        "answer": "According to Islamic tradition, the Kaaba was originally built by Prophet Ibrahim (Abraham) and his son Ismail (Ishmael) as a house of worship for Allah. It is located in Mecca and is the most sacred site in Islam."
    },

    # Ethics & Daily Life
    {
        "question": "What does Islam say about patience?",
        "answer": "The Quran says: 'Indeed, Allah is with the patient.' (2:153). Patience (Sabr) is one of the highest virtues in Islam. The Prophet (PBUH) said: 'No one has been given a better or vaster gift than patience.'"
    },
    {
        "question": "What is the Islamic greeting?",
        "answer": "The Islamic greeting is 'As-salamu alaykum' meaning 'Peace be upon you.' The response is 'Wa alaykum as-salam' meaning 'And upon you peace.' The Prophet (PBUH) encouraged spreading this greeting widely."
    },
    {
        "question": "What does Islam say about forgiveness?",
        "answer": "Islam highly values forgiveness. The Quran says: 'Let them pardon and overlook. Would you not like that Allah should forgive you?' (24:22). Allah's name Al-Ghafur means 'The Most Forgiving.'"
    },
    {
        "question": "What is halal food?",
        "answer": "Halal food refers to food that is permissible under Islamic law. It excludes pork, alcohol, and animals not slaughtered according to Islamic rites. The Quran instructs Muslims to eat what is halal and tayyib (pure)."
    },
    {
        "question": "What is the importance of Friday in Islam?",
        "answer": "Friday (Jumu'ah) is the most blessed day of the week in Islam. Muslims are required to attend the Friday congregational prayer (Salat al-Jumu'ah). The Prophet (PBUH) said: 'The best day on which the sun rises is Friday.'"
    }
]
